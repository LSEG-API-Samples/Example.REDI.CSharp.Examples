﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows.Input;
using RediLib;

namespace RediConsoleOrders
{
    class Order : INotifyPropertyChanged
    {
        private RediLib.CacheControl cancelcache;
        private RediLib.Application rediapp;
        private string err;

        public event PropertyChangedEventHandler PropertyChanged;
        private string _time;

        public string Time
        {
            get { return _time; }
            set { this._time=  value; }

        }

        private string _side;

        public string Side
        {
            get { return _side; }
            set { this._side= value; }

        }

        private string _quantity;

        public string Quantity
        {
            get { return _quantity; }
           set { this._quantity = value; }

        }

        private string _symbol;

        public string Symbol
        {
            get { return _symbol; }
            set { this._symbol = value; }
        }

        private string _pricedesc;

        public string PriceDesc
        {
            get { return _pricedesc; }
            set { this._pricedesc= value; }
        }

        private string _execquantity;

        public string ExecQuantity
        {
            get { return _execquantity; }
            set { this._execquantity= value; }
        }

        private string _pctcmp;

        public string PctCmp
        {
            get { return _pctcmp; }
            set { this._pctcmp= value; }
        }

        private string _lvs;

        public string Lvs
        {
            get { return _lvs; }
            set { this._lvs= value; }
        }



        private string _execpr;

        public string ExecPr
        {
            get { return _execpr; }
            set { this._execpr= value; }
        }


        private string _status;

        public string Status
        {
            get { return _status; }
            set { this._status= value; }
        }


        private string _account;

        public string Account
        {
            get { return _account; }
            set { this._account= value; }

        }

        private string _orderrefkey;

        public string OrderRefKey
        {
            get { return _orderrefkey; }
            set { this._orderrefkey= value; }

        }

   /*     private void IfLive()
        {
            Console.WriteLine("CancelByKey" + rediapp.UserID + " " + OrderRefKey + " " + err);
           //  cancelcache.CancelByBranchSequence(BranchSequence, err);
           cancelcache.CancelByKey(rediapp.UserID, OrderRefKey, err);
           // cancelcache.CancelByRefNum(UserId, OrderRefKey, err);
           //rediapp.CancelOrder(ClientData, err);
           //if (ClientData == "")
           // {
           //    rediapp.CancelOrdersByAcctSymbol(AccountAlias, Symbol, err);
           //  }
           //  else
           //  {
           //     rediapp.CancelOrder(ClientData, err);
           //  }
        }
        bool _live;
*/
        public override String ToString()
        {
            return "Ref="+OrderRefKey+"|Symbol=" + Symbol + "|Side=" + Side + "|Quantity=" + Quantity + "|ExecQuantity=" + ExecQuantity + "|PriceDesc=" + PriceDesc 
                + "|PctCmp=" + PctCmp + "|Lvs=" + Lvs + "|ExecPr=" + ExecPr + "|Account=" + Account + "|Status=" + Status;
        }
        
       /* bool OnIfLive
        {
            //if (OrdStat == "O")
            get
            {
                return _live;
                if (Status != "Completed" | Status != "Canceled")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

  */
    }
}
